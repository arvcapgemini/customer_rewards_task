package com.customer.rewards.customer_rewards.CustomerConstants;

public class CustomerConstants {
    public static final int daysInMonths = 30;
    public static int firstRewardLimit = 50;
    public static int secondRewardLimit = 100;
}
