package com.customer.rewards.customer_rewards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRewardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
